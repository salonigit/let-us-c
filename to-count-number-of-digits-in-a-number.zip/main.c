/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  long long num;
    int count = 0;
    printf("Enter any number: ");
    scanf("%lld", &num);
    count = log10(num) + 1;
    printf("Total digits: %d", count);
    return 0;
}
